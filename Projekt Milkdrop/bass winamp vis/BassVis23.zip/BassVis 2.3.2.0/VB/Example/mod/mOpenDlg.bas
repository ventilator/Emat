Attribute VB_Name = "mOpenDlg"
Option Explicit

Private Declare Function GetOpenFileName Lib "comdlg32.dll" _
        Alias "GetOpenFileNameA" (pOpenfilename As OPENFILENAME) _
        As Long
        
Private Declare Function GetSaveFileName Lib "comdlg32.dll" _
        Alias "GetSaveFileNameA" (pOpenfilename As OPENFILENAME) _
        As Long

Private Type OPENFILENAME
    lStructSize As Long
    hwndOwner As Long
    hInstance As Long
    lpstrFilter As String
    lpstrCustomFilter As String
    nMaxCustFilter As Long
    nFilterIndex As Long
    lpstrFile As String
    nMaxFile As Long
    lpstrFileTitle As String
    nMaxFileTitle As Long
    lpstrInitialDir As String
    lpstrTitle As String
    Flags As Long
    nFileOffset As Integer
    nFileExtension As Integer
    lpstrDefExt As String
    lCustData As Long
    lpfnHook As Long
    lpTemplateName As String
End Type

Public Const OFN_ALLOWMULTISELECT As Long = &H200&
Public Const OFN_CREATEPROMPT As Long = &H2000&
Public Const OFN_ENABLEHOOK As Long = &H20&
Public Const OFN_ENABLETEMPLATE As Long = &H40&
Public Const OFN_ENABLETEMPLATEHANDLE As Long = &H80&
Public Const OFN_EXPLORER As Long = &H80000
Public Const OFN_EXTENSIONDIFFERENT As Long = &H400&
Public Const OFN_FILEMUSTEXIST As Long = &H1000&
Public Const OFN_HIDEREADONLY As Long = &H4&
Public Const OFN_LONGNAMES As Long = &H200000
Public Const OFN_NOCHANGEDIR As Long = &H8&
Public Const OFN_NODEREFERENCELINKS As Long = &H100000
Public Const OFN_NOLONGNAMES As Long = &H40000
Public Const OFN_NONETWORKBUTTON As Long = &H20000
Public Const OFN_NOREADONLYRETURN As Long = &H8000&
Public Const OFN_NOTESTFILECREATE As Long = &H10000
Public Const OFN_NOVALIDATE As Long = &H100&
Public Const OFN_OVERWRITEPROMPT As Long = &H2&
Public Const OFN_PATHMUSTEXIST As Long = &H800&
Public Const OFN_READONLY As Long = &H1&
Public Const OFN_SHAREAWARE As Long = &H4000&
Public Const OFN_SHAREFALLTHROUGH As Long = 2&
Public Const OFN_SHARENOWARN As Long = 1&
Public Const OFN_SHAREWARN As Long = 0&
Public Const OFN_SHOWHELP As Long = &H10&

Public Function ShowOpen(Filter As String, Flags As Long, hWnd As Long) As String
    Dim Buffer As String
    Dim Result As Long
    Dim ComDlgOpenFileName As OPENFILENAME
    
    Buffer = String$(128, 0)
    
    With ComDlgOpenFileName
        .lStructSize = Len(ComDlgOpenFileName)
        .hwndOwner = hWnd
        .Flags = Flags
        .nFilterIndex = 1&
        .nMaxFile = Len(Buffer)
        .lpstrFile = Buffer
        .lpstrFilter = Filter
    End With
    
    Result = GetOpenFileName(ComDlgOpenFileName)
    
    If Result <> 0 Then
        ShowOpen = Left$(ComDlgOpenFileName.lpstrFile, _
                   InStr(ComDlgOpenFileName.lpstrFile, _
                   Chr$(0)) - 1)
    End If
End Function

Public Function ShowSave(Filter As String, Flags As Long, _
                         hWnd As Long, FileName As String) As String
                           
    Dim Buffer As String
    Dim Result As Long
    Dim ComDlgOpenFileName As OPENFILENAME
    
    Buffer = FileName & String$(128 - Len(FileName), 0)
    
    With ComDlgOpenFileName
        .lStructSize = Len(ComDlgOpenFileName)
        .hwndOwner = hWnd
        .Flags = OFN_HIDEREADONLY Or OFN_PATHMUSTEXIST
        .nFilterIndex = 1&
        .nMaxFile = Len(Buffer)
        .lpstrFile = Buffer
        .lpstrFilter = Filter
    End With
    
    Result = GetSaveFileName(ComDlgOpenFileName)
    
    If Result <> 0 Then
        ShowSave = Left$(ComDlgOpenFileName.lpstrFile, _
                   InStr(ComDlgOpenFileName.lpstrFile, _
                   Chr$(0)) - 1)
    End If
End Function


